﻿namespace crud_mvc.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string? ProductName { get; set; }
        public int  categoryID { get; set; }

        public string? categoryName { get; set; }

    }
}
