﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using crud_mvc.Models;

namespace crud_mvc.Data
{
    public class crud_mvcContext : DbContext
    {
        public crud_mvcContext (DbContextOptions<crud_mvcContext> options)
            : base(options)
        {
        }

        public DbSet<crud_mvc.Models.Product> Product { get; set; } = default!;
    }
}
